# IPMAN Analytics — Fase 2

Frontend industrial demonstrativo em React, TypeScript, Vite e Three.js com React Three Fiber. Nove telas integradas, dados simulados, inspeção visual com evidências e Digital Twin interativo. Sem backend, banco, coleta externa ou chamadas a APIs reais. Os únicos requests da aplicação são para seus próprios arquivos estáticos.

## Executar

Pré-requisito: Docker Engine/Desktop com Compose v2, em execução.

```sh
docker compose up
```

Abra **http://localhost:8080**. O primeiro comando instala e compila tudo na imagem; não é necessário Node no host. `docker compose down` encerra. Após alterações de código, use `docker compose up --build`. A porta pode ser alterada em `docker-compose.yml`. O Nginx serve o build estático, com healthcheck e fallback de navegação.

Alternativa para desenvolvimento (Node 22.12+ ou 24):

```sh
npm ci
npm run dev
```

Abra http://localhost:5173. Build de produção: `npm run build`; prévia: `npm run preview`.

## Telas e fidelidade

As páginas 10–14 do PDF fornecido definem exatamente a sequência **Visão geral → Qualidade dos dados → Referências → Condição dos ativos → Investigações**. A página 9 usa nomes resumidos; adotamos os rótulos completos dos próprios menus dos cinco wireframes.

Em seguida vêm a seção **Inspeção Visual**, com **Inspeção atual**, **Referência de inspeção**, **Histórico de Inspeção**, e, como última opção, **Digital Twin**, conforme o pedido. Layout claro, menu azul escuro, destaque azul, cartões, séries, mapas de condição e estados verde/âmbar/vermelho seguem os wireframes. Layout responsivo e controles por teclado.

| Tela                   | Funcionalidades                                                                                                   |
| ---------------------- | ----------------------------------------------------------------------------------------------------------------- |
| Visão geral            | Indicadores, mapa de seis ativos, fila e tendência; drill-down para condição/investigação                         |
| Qualidade dos dados    | Disponibilidade, matriz de completude/sincronismo/clipping/congelamento e sinal                                   |
| Referências            | Série com envelope, distribuição e heatmap de features                                                            |
| Condição dos ativos    | Condição por ativo, evidências e priorização                                                                      |
| Investigações          | Linha do tempo e registro de hipótese/observação na sessão                                                        |
| Inspeção atual         | Imagem original, overlays clicáveis, esperado × detectado, qualidade física e sinalização; nova inspeção simulada |
| Referência de inspeção | Consulta por PN, validação de importação, ativação e rollback de versões                                          |
| Histórico de Inspeção  | Pesquisa por identificador/PN, filtro por resultado, evidência individual e revisão humana                        |
| Digital Twin           | Órbita, zoom, seleção de componentes, vista inicial, raio-X da carcaça, labels ao vivo, pausa e cenários por componente                 |

Filtros analíticos permanecem ao navegar. Os dados são determinísticos; selecionar máquina aplica uma variação demonstrativa à série, selecionar ativo restringe os cartões/matrizes, e o período altera a janela exibida. Não representam medições reais. A imagem da peça foi extraída do próprio PDF (página 16); os overlays são vetores da aplicação inspirados na página 17, e não resultados reais de OCR. O cenário inicial mantém PN 265258072, v12, 8/11 conformes, duas divergências incluindo qualidade física e um campo ausente. PNs e marcações observáveis podem diferir na fotografia ilustrativa, como já ocorre no wireframe.

## Dados, estado e integração futura

`src/data.ts` é a fonte única de dados mock, organizada em `plant`, `inspection`, `references` e `simulation`. Inclui tipos e `demoRepository.inspect()`, que simula latência. Os componentes não acessam rede. Uma futura integração pode substituir o adaptador do repositório e fornecer os mesmos contratos, sem reescrever a apresentação. Séries derivadas e resultados what-if são cálculos, não novos datasets espalhados pelos componentes.

Ativação/rollback, revisão e resultados são mantidos em memória na sessão React e se perdem ao recarregar. O idioma é a única preferência salva em localStorage. O cabeçalho exibe Online e a hora atual com segundos no fuso America/Sao_Paulo. As evidências e os contadores de Inspeção Visual continuam como fotografias versionadas do slide. Os demais sinais são renovados a cada segundo. A retenção de 90 dias é apenas conceitual: não existe armazenamento de imagens nem processo de descarte.

### Importação de referências

Na tela de referências, **Enviar nova versão** aceita JSON e XLSX, até 1 MiB. O parser valida antes de ativar; versões anteriores permanecem disponíveis para rollback. PN deve ter nove dígitos; cliente e família devem ser strings, e campos devem ter identificadores únicos e valores em texto. Usos aceitos: `Identificação`, `Part Number`, `Gravação`.

JSON de exemplo em `public/reference/reference-example.json`:

```json
{
  "pns": {
    "265258072": {
      "client": "VW",
      "family": "ESP9-6",
      "fields": [
        { "id": "Field 0", "value": "ESP", "use": "Identificação" },
        { "id": "Field 1", "value": "265258072", "use": "Part Number" }
      ]
    }
  }
}
```

Para XLSX, a primeira planilha deve ter as colunas exatas `pn`, `client`, `family`, `field`, `value`, `use`, uma linha por campo. PNs numéricos são convertidos em texto, mas prefira formatá-los como texto no Excel para conservar zeros iniciais. Não executamos macros. Arquivos inválidos exibem erro e preservam a versão ativa.

## Digital Twin e img2threejs

Foi utilizado o [img2threejs](https://github.com/img2threejs/img2threejs), revisão `954cd5845e90efd045694bab725d68a9863c20e0`: ferramentas de intake, admissão da referência, busca de especificações, scaffold de avaliação/especificação, inventário por regiões e extração de evidências PBR. O img2threejs é um fluxo assistido de **reconstrução procedural em código**, não um conversor automático de pixels para malha nem fotogrametria.

O artefato utilizável pelo Three.js é `src/g300.generated.ts`, fábrica `createG300Model()` independente de React, com geometrias, materiais e pivôs. `src/Twin.tsx` integra o modelo via R3F. Referência original em `public/reference/g300.png`; avaliação, especificação, admissão, recortes e mapas gerados em `docs/model/`. Processo e limites completos em [docs/model/CONVERSION.md](docs/model/CONVERSION.md).

A reconstrução é **aproximada**, refinada com as duas fotografias fornecidas: carcaça clara aberta, coroas azuis, identificadores GROB/G300, mesa circular, spindle horizontal, painel, tanque vermelho e fileiras de ferramentas. Faces ocultas e dimensões foram inferidas; não é CAD oficial nem gêmeo calibrado. Não alegamos aprovação completa dos gates fotométricos do img2threejs. A peça sobre a mesa é inspirada no bloco metálico com gravuras e corpo preto da página 16; acompanha a mesa giratória. A velocidade visual do spindle é reduzida para legibilidade; não reproduz 6.000 giros reais por minuto.

Controles: arrastar para orbitar; roda do mouse ou gesto de pinça para zoom; clicar para selecionar; botões para vista inicial, raio-X, labels e pausa. No raio-X, apenas a carcaça fica transparente; spindle, motor, bombas e mesa permanecem opacos e animados. WebGL2 é necessário. Sem suporte WebGL, falhas React ou erro no carregamento exibem mensagem e recuperação. Não há dependência de modelos, fontes ou HDRIs hospedados externamente.

### What-if

`src/twin-engine.ts` contém o modelo por componente. O seletor oferece spindle, motor principal, três bombas e mesa giratória. Cada unidade preserva sua configuração ao trocar de seleção. Parâmetros: rotação, carga e desbalanceamento; para bombas, o terceiro controle é restrição hidráulica. Os cards superiores exibem RMS de vibração, corrente, potência, FP e Anomaly Score do componente selecionado.

Labels na cena mostram nome, RMS e corrente de cada conjunto. A condição colore os componentes em verde/âmbar/vermelho e aumenta a vibração visível. Há transferência de vibração entre motor, spindle e mesa, e influência da bomba 1 no spindle. O botão de raio-X torna só os materiais da carcaça transparentes. A geometria está em `src/g300.model.ts`, reexportada por `src/g300.generated.ts`. Detalhes e limites em [docs/model/REFINEMENT-v1.1.md](docs/model/REFINEMENT-v1.1.md). `src/simulation.ts` conserva o contrato numérico inicial para compatibilidade e seus testes.

### Atualização a cada segundo e viewport

`src/live.tsx` centraliza um único timer de 1.000 ms, relógio e snapshots imutáveis derivados dos dados de `src/data.ts`. Disponibilidade, RMS, grandezas elétricas, séries temporais, distribuição, heatmaps, cobertura e duração operacional evoluem sem recarregar. Os componentes não criam timers independentes. O timer é descartado ao desmontar a aplicação. O cabeçalho usa a hora real; as leituras continuam sendo geradas localmente, sem conexão com equipamento físico.

Os avisos de demonstração foram retirados da interface operacional. **Inspeção Visual foi preservada**: seu arquivo, evidências, resultados, referências e interações não foram alterados pelo timer. Não se devem atualizar evidências históricas como se fossem sinais correntes.

Dashboards e Twin ocupam a altura útil da janela. Em telas compactas, botões Painel principal/Análise detalhada e Equipamento/Cenário what-if alternam os painéis disponíveis, mantendo os controles acessíveis sem rolagem da página operacional. As telas de inspeção conservam o layout original e sua rolagem de conteúdo.

## Idiomas

Português é o padrão. O seletor **Português / English** no cabeçalho troca o idioma sem recarregar, inclusive menus, status, mensagens e conteúdo descritivo mock. Catálogos em `src/locales/pt.json` e `src/locales/en.json`, contexto em `src/i18n.tsx`. Números e datas usam `Intl` com `pt-BR`/`en-US`. Identificadores de PN, marcações reais da peça, nomes comerciais, unidades e texto livre digitado pelo usuário são mantidos como dados.

## Estrutura

```text
src/
  App.tsx                 shell, navegação e estado compartilhado
  Dashboards.tsx          cinco telas analíticas
  Inspection.tsx          inspeção, referências e histórico
  Twin.tsx                cena R3F e controles what-if
  g300.model.ts           geometria detalhada e pivôs por componente
  g300.generated.ts       import estável da fábrica procedural
  twin-engine.ts          cenários, acoplamento e condição por componente
  live.tsx                clock e snapshots sincronizados a cada segundo
  live-styles.css         viewport operacional e painéis compactos
  data.ts                 contratos e dados mock por domínio
  simulation.ts           cálculos puros da simulação
  referenceImport.ts      parsing JSON/XLSX e validação
  i18n.tsx, locales/      idioma e catálogos PT/EN
  ui.tsx, styles.css      componentes, erros, gráficos e layout
e2e/                      testes de navegador
docs/reference/           páginas renderizadas do PDF fornecido
docs/model/               proveniência e artefatos img2threejs
docs/qa/                  capturas dos testes visuais
tools/img2threejs/         ferramenta upstream usada (Apache-2.0)
```

## Testes e verificação

```sh
npm ci
npm test
npm run build
npx playwright install chromium
npm run test:e2e
```

Vitest/Testing Library cobrem navegação, contexto de filtros, idiomas, as três telas de inspeção, filtros e revisão do histórico, consulta/rollback/validação de referência, falha de imagem e cálculos what-if (baseline, monotonicidade e limites). Playwright cobre navegação real, inspeção, inglês, evidências, 3D WebGL com Chromium/SwiftShader, controles what-if e layout móvel. O build de produção e a prévia Vite (porta 4173) são iniciados automaticamente se não estiverem ativos. Capturas em `docs/qa/`. Compilação TypeScript estrita antes do build. `npm audit` verifica dependências.

Limite do ambiente de entrega: Docker não estava instalado; o comando Compose não pôde ser executado aqui. O build estático e os testes são executados no host; não confunda essa validação com um teste do contêiner. Não é necessário serviço externo ou chave de API para executar a demonstração.

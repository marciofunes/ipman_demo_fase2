import { test, expect } from '@playwright/test';
test('inspection, language, reference and history end to end', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Visão geral', exact: true })).toBeVisible();
  await page.screenshot({ path: 'docs/qa/overview.png', fullPage: true });
  await page
    .getByRole('navigation')
    .getByRole('button', { name: 'Inspeção atual', exact: true })
    .click();
  await expect(page.getByText('8 / 11')).toBeVisible();
  await page.screenshot({ path: 'docs/qa/inspection.png', fullPage: true });
  await page.getByLabel('Idioma').selectOption('en');
  await expect(
    page.getByRole('heading', { name: 'Current inspection', exact: true }),
  ).toBeVisible();
  await page.getByRole('button', { name: 'Inspection reference', exact: true }).click();
  await expect(page.getByText('Expected fields for selected PN')).toBeVisible();
  await page.getByRole('button', { name: 'Inspection History', exact: true }).click();
  await page.getByRole('button', { name: 'Open evidence 2026-054631' }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.getByRole('button', { name: 'Close', exact: true }).click();
});
test('3D renders, what-if responds and controls work', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  await page.getByRole('button', { name: 'Digital Twin', exact: true }).click();
  await expect(page.locator('canvas')).toBeVisible();
  await page.waitForTimeout(2500);
  await expect(page.getByTestId('twin-rms')).toBeVisible();
  await page.screenshot({ path: 'docs/qa/twin.png', fullPage: true });
  await expect(page.locator('.annotation-layer .machine-label:visible')).toHaveCount(6);
  await page.getByRole('button', { name: 'Pausar processo' }).click();
  await page.getByRole('button', { name: 'Raio-X', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Raio-X', exact: true })).toHaveAttribute(
    'aria-pressed',
    'true',
  );
  await page.getByLabel('Componente', { exact: true }).selectOption('motor');
  await page.getByRole('slider', { name: 'Desbalanceamento', exact: true }).fill('100');
  await expect(page.locator('.component-condition strong')).toHaveText('Crítico');
  await expect
    .poll(async () =>
      Number(
        (await page.getByTestId('twin-rms').innerText())
          .replace('mm/s', '')
          .trim()
          .replace(',', '.'),
      ),
    )
    .toBeGreaterThan(8);
  await page.screenshot({ path: 'docs/qa/twin-xray.png', fullPage: true });
  await page.getByLabel('Componente', { exact: true }).selectOption('pump1');
  await page.getByRole('slider', { name: 'Restrição hidráulica', exact: true }).fill('90');
  await expect(page.locator('.component-condition strong')).toHaveText('Crítico');
  await expect(page.getByRole('button', { name: 'Iniciar processo' })).toBeVisible();
  await page.getByRole('button', { name: 'Restaurar cenário', exact: true }).click();
  await page.getByRole('button', { name: 'Vista inicial' }).click();
  await expect(page.locator('.annotation-layer .machine-label:visible')).toHaveCount(6);
  await page
    .getByRole('navigation')
    .getByRole('button', { name: 'Visão geral', exact: true })
    .click();
  await expect(page.getByRole('heading', { name: 'Visão geral', exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});

test('one-second data and current clock update together', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('.live-status')).toContainText('Online');
  const clock = await page.getByLabel('Hora atual').textContent();
  const points = await page.locator('.chart polyline').first().getAttribute('points');
  await expect
    .poll(() => page.getByLabel('Hora atual').textContent(), { timeout: 5000 })
    .not.toBe(clock);
  await expect
    .poll(() => page.locator('.chart polyline').first().getAttribute('points'), { timeout: 5000 })
    .not.toBe(points);
  await expect(page.getByText('Demonstração • dados simulados')).toHaveCount(0);
});

test('operational dashboards fit desktop viewport without page scroll', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('/');
  for (const name of [
    'Visão geral',
    'Qualidade dos dados',
    'Referências',
    'Condição dos ativos',
    'Investigações',
  ]) {
    await page.getByRole('navigation').getByRole('button', { name, exact: true }).click();
    expect(
      await page.evaluate(
        () =>
          document.documentElement.scrollHeight <= innerHeight + 1 &&
          document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await page.screenshot({
      path: `docs/qa/live-${['Visão geral', 'Qualidade dos dados', 'Referências', 'Condição dos ativos', 'Investigações'].indexOf(name)}.png`,
    });
  }
});

test('mobile Twin uses viewport panels without scrolling', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await page.getByRole('button', { name: 'Abrir menu' }).click();
  await page
    .getByRole('navigation')
    .getByRole('button', { name: 'Digital Twin', exact: true })
    .click();
  await expect(page.locator('canvas')).toBeVisible();
  await expect(page.locator('.annotation-layer .machine-label:visible')).toHaveCount(6);
  await page.screenshot({ path: 'docs/qa/twin-mobile.png' });
  await page.locator('.twin-mobile-tabs').getByRole('button', { name: 'Cenário what-if' }).click();
  await expect(page.getByLabel('Componente', { exact: true })).toBeVisible();
  await page.getByLabel('Componente', { exact: true }).selectOption('pump2');
  await expect(page.getByRole('slider', { name: 'Restrição hidráulica' })).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        document.documentElement.scrollHeight <= innerHeight + 1 &&
        document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({ path: 'docs/qa/twin-mobile-controls.png' });
  const action = await page.locator('.twin-actions .primary').boundingBox();
  expect(action!.y + action!.height).toBeLessThanOrEqual(844);
  await page.setViewportSize({ width: 844, height: 390 });
  await page.getByLabel('Parâmetro', { exact: true }).selectOption('restriction');
  await expect(
    page.getByRole('slider', { name: 'Restrição hidráulica', exact: true }),
  ).toBeVisible();
  const landscapeAction = await page.locator('.twin-actions .primary').boundingBox();
  expect(landscapeAction!.y + landscapeAction!.height).toBeLessThanOrEqual(390);
  await page.screenshot({ path: 'docs/qa/twin-landscape-controls.png' });
});

test('mobile analytical panels remain accessible without page scroll', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  for (const name of [
    'Visão geral',
    'Qualidade dos dados',
    'Referências',
    'Condição dos ativos',
    'Investigações',
  ]) {
    await page.getByRole('button', { name: 'Abrir menu' }).click();
    await page.getByRole('navigation').getByRole('button', { name, exact: true }).click();
    await page.getByRole('button', { name: 'Análise detalhada', exact: true }).click();
    expect(
      await page.evaluate(
        () =>
          document.documentElement.scrollHeight <= innerHeight + 1 &&
          document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    if (name === 'Investigações')
      await expect(
        page.getByRole('button', { name: 'Registrar resultado', exact: true }),
      ).toBeVisible();
    if (name === 'Visão geral') await page.screenshot({ path: 'docs/qa/live-mobile.png' });
  }
});
test('mobile navigation remains usable', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await page.getByRole('button', { name: 'Abrir menu' }).click();
  await page
    .getByRole('navigation')
    .getByRole('button', { name: 'Inspeção atual', exact: true })
    .click();
  await expect(page.getByRole('heading', { name: 'Inspeção atual', exact: true })).toBeVisible();
  await page.screenshot({ path: 'docs/qa/mobile.png', fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('validates and activates an XLSX reference', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Referência de inspeção', exact: true }).click();
  await page.locator('input[type=file]').setInputFiles('e2e/fixtures/reference.xlsx');
  await expect(page.getByText('Referência validada e ativada nesta sessão.')).toBeVisible();
  await expect(page.getByText('v13', { exact: true }).first()).toBeVisible();
  await page.screenshot({ path: 'docs/qa/reference.png', fullPage: true });
});
